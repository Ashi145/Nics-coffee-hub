
  # Cafe Website with 3D Transitions

  This is a code bundle for Cafe Website with 3D Transitions. The original project is available at https://www.figma.com/design/lsvfAdjP6bIFCn0thugJrd/Cafe-Website-with-3D-Transitions.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  